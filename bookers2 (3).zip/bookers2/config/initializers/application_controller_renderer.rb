# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'f8c0b5d2d129c763185aa2672c3c14541c70730292be14092e6c2bbd7ca0be67a91112b9ee402084b18758de1bf1cb824559f8e28b8d2a69795b184bde1ad2da'